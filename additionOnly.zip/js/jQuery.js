getEquation();
function reset() {
	enable();
	$(".try-again").hide();
	$(".try-again").off();
	$(".answer").addClass("possible");
	$(".answer").removeClass("answer");
	getEquation();
}
// Suffle algorithm found on Stack Overflow
function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

// Generates New Equation and Answer
function getEquation() {
	const numOne = Math.floor(Math.random() * 9) + 1;
	const numTwo = Math.floor(Math.random() * 9) + 1;
	answer = numOne + numTwo;
	$(".equation").text([`${numOne} + ${numTwo}`]);
	getOtherAnswers();
	console.log(answer);
}


// Generates Wrong Options
function getOtherAnswers () {
	otherAnswers = [];
	while (otherAnswers.length < 3) {
	    const random_number = Math.floor(Math.random() * 18) + 2;
	    if (!otherAnswers.includes(random_number) && random_number != answer) otherAnswers.push(random_number);

	}
	const optionOne = $(".option-one");
	const optionTwo = $(".option-two");
	const optionThree = $(".option-three");
	const optionFour = $(".option-four");

	const arr = [optionOne, optionTwo, optionThree, optionFour];
	const item = arr[Math.floor(Math.random()*arr.length)];
	item.text(answer);
	item.addClass("answer");
	item.removeClass("possible");
	console.log(otherAnswers);

	printAnswers();
}

// Randomizes wrong answers onto screen
function printAnswers () {
	shuffle(otherAnswers);
	$('.possible').each(function(i, obj) {
		var shuffled = otherAnswers[i];
	    $(this).text(shuffled); 
	});

	$(".answer").on("click", function() {
		disable();
		$(".try-again").show();
		$(".try-again").on("click", function() {
			reset();
		});
	});
	$(".possible").on("click", function() {
		$(this).fadeOut("slow");
		$("#incorrect").show();
	});
}
// Disable buttons after correct answer is chosen
function disable() {
	$("#incorrect").hide();
	$("a").removeAttr("href");
	$("a").css({
		"opacity": 0.5,
		"color": "#e0f7fa",
		"background": "#33b5e5"
	});
	$(".possible").off();
	$(".answer").off();
}
// Renable buttons
function enable() {
	$("a").attr("href", "#");
	$("a").css("opacity", 1);
	$("a").show();
	$("a").hover(function() {
		$(this).css("background", "#ff4444");
	}, 
	function() {
		$(this).css("background", "#33b5e5");
	});
}